--
-- PostgreSQL database dump

-- Required extensions (run these commands first if needed):
-- CREATE EXTENSION IF NOT EXISTS pgcrypto;
--
--

-- Dumped from database version 16.9 (63f4182)
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.property_images DROP CONSTRAINT IF EXISTS property_images_property_id_fkey;
ALTER TABLE IF EXISTS ONLY public.property_documents DROP CONSTRAINT IF EXISTS property_documents_property_id_fkey;
DROP INDEX IF EXISTS public.idx_property_images_sort_order;
DROP INDEX IF EXISTS public.idx_property_images_property_id;
DROP INDEX IF EXISTS public.idx_property_images_is_main;
DROP INDEX IF EXISTS public.idx_property_documents_property_id;
DROP INDEX IF EXISTS public.idx_properties_transaction_type;
DROP INDEX IF EXISTS public.idx_properties_property_type;
DROP INDEX IF EXISTS public.idx_properties_price;
DROP INDEX IF EXISTS public.idx_properties_featured;
DROP INDEX IF EXISTS public.idx_properties_created_at;
DROP INDEX IF EXISTS public.idx_properties_city_region;
DROP INDEX IF EXISTS public.idx_properties_active;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.properties DROP CONSTRAINT IF EXISTS unique_property_code;
ALTER TABLE IF EXISTS ONLY public.services DROP CONSTRAINT IF EXISTS services_pkey;
ALTER TABLE IF EXISTS ONLY public.sections DROP CONSTRAINT IF EXISTS sections_pkey;
ALTER TABLE IF EXISTS ONLY public.property_images DROP CONSTRAINT IF EXISTS property_images_pkey;
ALTER TABLE IF EXISTS ONLY public.property_documents DROP CONSTRAINT IF EXISTS property_documents_pkey;
ALTER TABLE IF EXISTS ONLY public.properties DROP CONSTRAINT IF EXISTS properties_pkey;
ALTER TABLE IF EXISTS ONLY public.pages DROP CONSTRAINT IF EXISTS pages_slug_key;
ALTER TABLE IF EXISTS ONLY public.pages DROP CONSTRAINT IF EXISTS pages_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.services;
DROP TABLE IF EXISTS public.sections;
DROP TABLE IF EXISTS public.property_images;
DROP TABLE IF EXISTS public.property_documents;
DROP TABLE IF EXISTS public.properties;
DROP TABLE IF EXISTS public.pages;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pages (
    id character varying(36) NOT NULL,
    slug character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    meta_description text,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: properties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.properties (
    id character varying(36) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    price numeric(12,2) NOT NULL,
    currency character varying(3) DEFAULT 'EUR'::character varying,
    transaction_type character varying(10),
    property_type character varying(100) NOT NULL,
    city_region character varying(100) NOT NULL,
    district character varying(100),
    address text,
    area numeric(8,2) NOT NULL,
    bedrooms integer,
    bathrooms integer,
    floors integer,
    floor_number integer,
    terraces integer,
    construction_type character varying(50),
    condition_type character varying(50),
    heating character varying(50),
    exposure character varying(50),
    year_built integer,
    furnishing_level character varying(50),
    has_elevator boolean DEFAULT false,
    has_garage boolean DEFAULT false,
    has_southern_exposure boolean DEFAULT false,
    new_construction boolean DEFAULT false,
    featured boolean DEFAULT false,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    property_code character varying(50),
    CONSTRAINT properties_transaction_type_check CHECK (((transaction_type)::text = ANY ((ARRAY['sale'::character varying, 'rent'::character varying])::text[])))
);


--
-- Name: property_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.property_documents (
    id character varying(36) DEFAULT (gen_random_uuid())::text NOT NULL,
    property_id character varying(36) NOT NULL,
    filename character varying(255) NOT NULL,
    original_filename character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(100) DEFAULT 'application/pdf'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: property_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.property_images (
    id character varying(36) NOT NULL,
    property_id character varying(36) NOT NULL,
    image_url character varying(500) NOT NULL,
    image_path character varying(500),
    alt_text character varying(255),
    sort_order integer DEFAULT 0,
    is_main boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    thumbnail_url character varying(255),
    file_size integer DEFAULT 0,
    mime_type character varying(50)
);


--
-- Name: sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sections (
    id character varying(36) NOT NULL,
    title character varying(255) NOT NULL,
    content text,
    type character varying(100) NOT NULL,
    active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id character varying(36) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    icon character varying(100),
    active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying(36) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'admin'::character varying,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pages (id, slug, title, content, meta_description, active, created_at, updated_at) FROM stdin;
page-002	about	За нас	<h2>ConsultingG Real Estate</h2><p>Водещата компания за недвижими имоти в България с над 15 години опит в сферата.</p>	Научете повече за ConsultingG Real Estate	t	2025-09-22 11:17:12.254228	2025-09-22 11:17:12.254228
page-003	contact	Контакти	<h2>Свържете се с нас</h2><p>Телефон: 0888 825 445</p><p>Имейл: office@consultingg.com</p>	Свържете се с ConsultingG Real Estate	t	2025-09-22 11:17:12.254228	2025-09-22 11:17:12.254228
page-001	home	Начало	<h1>1Добре дошли в ConsultingG Real Estate</h1><p>Водещата платформа за недвижими имоти в България с над 15 години опит.</p>	ConsultingG Real Estate - водещата платформа за недвижими имоти в България	t	2025-09-22 11:17:12.254228	2025-09-23 15:48:41.829583
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.properties (id, title, description, price, currency, transaction_type, property_type, city_region, district, address, area, bedrooms, bathrooms, floors, floor_number, terraces, construction_type, condition_type, heating, exposure, year_built, furnishing_level, has_elevator, has_garage, has_southern_exposure, new_construction, featured, active, created_at, updated_at, property_code) FROM stdin;
prop-004	Апартамент под наем в Оборище	Уютен двустаен апартамент за дългосрочен наем в престижния квартал Оборище.	1200.00	EUR	rent	2-СТАЕН	София	Оборище	ул. Шипка 15	75.00	1	1	6	3	1	Тухла	Обзаведен	ТЕЦ	Юг	2015	full	t	f	t	f	t	t	2025-09-22 11:17:12.254228	2025-09-22 11:17:12.254228	\N
prop-008	Модерна самостоятелна къща с двор и панорамни гледки в Драгалевци	✨ Модерна самостоятелна къща с двор и панорамни гледки в Драгалевци ✨\n\nРазположена на ул. Пчелица, в близост до Киноцентъра, къщата предлага комфорт, функционалност и завършеност до ключ. Имотът е с Акт 16 / 2023 г., разполага с РЗП 460 кв.м и самостоятелен двор от 420 кв.м.\n\n🏡 Основни характеристики:\n• РЗП къща: 460 кв.м\n• Двор: 420 кв.м\n• Етажи: 3\n• Разрешение за ползване: Акт 16 / 2023 г.\n• Състояние: завършена до ключ	1250000.00	EUR	sale	КЪЩА	София	Драгалевци	ул. Пчелица, в близост до Киноцентъра	460.00	4	4	3	0	1	Тухла	Завършена до ключ	Климатици	Ю-И-З	2023	partial	f	f	t	f	t	t	2025-09-22 15:44:18.162656	2025-09-22 16:28:57.018695	\N
prop-007	✨ Слънчев четиристаен апартамент в Оборище с панорамни гледки ✨	Представяме ви просторен и светъл апартамент, разположен в сърцето на кв. Оборище, в непосредствена близост до Малък градски театър, парк „Заимов", метростанция Театрална и удобни спирки на градски транспорт. Жилището разкрива впечатляващи гледки към Витоша и към емблематичния храм-паметник „Св. Александър Невски".\n\n📐 Разпределение:\n• Просторна всекидневна с кухненски бокс\n• Три самостоятелни спални\n• Две бани с тоалетни\n• Отделна тоалетна за гости\n• Три тераси с гледки	1500.00	EUR	rent	4-СТАЕН	София	Оборище	кв. Оборище, близо до метростанция Театрална	120.00	3	2	8	7	0	Панел	Отлично	ТЕЦ	Ю-И-З	2025	full	t	f	t	f	t	t	2025-09-22 15:44:13.54383	2025-09-22 15:53:14.065193	\N
prop-001	Луксозен апартамент в Симеоново	Прекрасен тристаен апартамент в престижния квартал Симеоново с панорамна гледка към Витоша.	290000.00	EUR	sale	3-СТАЕН	София	Симеоново	ул. Симеоновско шосе 123	145.50	2	2	8	5	1	Тухла	Ново строителство	Локално	Юг	2023	full	t	t	t	t	t	t	2025-09-22 11:17:12.254228	2025-09-22 17:20:12.511706	\N
prop-002	Къща в Драгалевци	Уютна двуетажна къща в подножието на Витоша. Идеална за семейство, търсещо спокойствие и близост до природата.	450000.00	EUR	sale	КЪЩА	София	Драгалевци	ул. Драгалевска 45	220.00	4	3	2	0	2	Тухла	След ремонт	Локално	Ю-З	2018	partial	f	t	t	f	t	t	2025-09-22 11:17:12.254228	2025-09-22 15:29:55.022654	\N
prop-006	Самостоятелна къща с 360° панорамна гледка в кв. Бояна	✨ Самостоятелна къща с 360° панорамна гледка в кв. Бояна ✨\n\nИзключителен дом, предлагащ изглед към Витоша, Ботаническата градина и София. Ново строителство (2026 г.), разположен на обилен парцел в престижната Бояна, с материали и технологии от висок клас.\n\n🏡 Характеристики:\n\n• РЗП: 538,80 кв.м\n\n• Двор: 1101 кв.м – ландшафтен дизайн\n\n• Конструкция: тухла Wienerberger\n\n• Дограма: алуминиева с троен стъклопакет ETEM\n\n• Отопление: термопомпа Daikin + газово котле + подово отопление + конвектори\n\n• Гараж: подземен за 3 автомобила + фитнес със сауна	1350000.00	EUR	sale	КЪЩА	София	Бояна	кв. Бояна	538.80	3	5	3	0	3	Тухла	Ново строителство	Локално	Юг	2026	none	f	t	t	t	t	t	2025-09-22 15:44:04.150954	2025-09-22 15:44:04.150954	\N
prop-009	Офис площи / Обект "Метличина поляна 15", кв. Гоце Делчев	✨ Офис площи / Обект "Метличина поляна 15", кв. Гоце Делчев ✨\n\nТози имот предлага функционални офис пространства, разположени в добре позиционирана реновирана сграда с отлична достъпност и силна локация.\n\n🏢 Основни характеристики:\n• Обект: самостоятелен офис в сграда с монолитна стоманобетонова конструкция\n• Разрешение за ползване: Акт 16 / 2024 г. (очакван)\n• Площ: ≈ 1 117.58 кв.м общо по документи\n• Нива: две нива (партер и първи етаж)	8.00	EUR	rent	ОФИС	София	Гоце Делчев	ул. Метличина поляна 15	1117.58	\N	2	2	\N	\N	Монолит	\N	ТЕЦ	Ю-И	2024	none	t	t	f	f	t	t	2025-09-22 15:44:37.226311	2025-09-24 04:22:45.112307	\N
prop-010	Луксозна самостоятелна къща в кв. Бояна | 580.70 кв.м РЗП | Двор 1200 кв.м | 360° панорама	🏡 Луксозна самостоятелна къща в кв. Бояна | 580.70 кв.м РЗП | Двор 1200 кв.м | 360° панорама\n\nНова къща в процес на строителство, с планирано въвеждане в експлоатация през 2026 г., разположена в престижната част на кв. Бояна. Имотът се отличава с южно изложение, панорамни 360° гледки към Витоша, Ботаническата градина и цяла София, двор от 1200 кв.м с професионален ландшафтен проект, както и големи тераси със стъклени парапети, осигуряващи простор и светлина.	2170000.00	EUR	sale	КЪЩА	София	Бояна	кв. Бояна	580.70	4	5	3	\N	4	Тухла	\N	Термопомпа	Юг	2026	none	f	t	t	t	f	t	2025-09-22 15:44:46.505821	2025-09-24 04:18:57.205301	\N
\.


--
-- Data for Name: property_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.property_documents (id, property_id, filename, original_filename, file_path, file_size, mime_type, created_at) FROM stdin;
\.


--
-- Data for Name: property_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.property_images (id, property_id, image_url, image_path, alt_text, sort_order, is_main, created_at, thumbnail_url, file_size, mime_type) FROM stdin;
img-007	prop-004	/images/prop-007/ap_oborichte_1.jpg	/images/prop-007/ap_oborichte_1.jpg	Апартамент под наем в Оборище - главна снимка	0	t	2025-09-22 11:17:23.062397	\N	0	\N
41d79f7b-9d2f-4d07-a614-aaa0dffa8851	prop-006	/uploads/properties/prop-006/prop_prop-006_prop_prop-008_9_ap_oborichte_1758550168_1b6229_1758555910_4b7b1d.jpg	/uploads/properties/prop-006/prop_prop-006_prop_prop-008_9_ap_oborichte_1758550168_1b6229_1758555910_4b7b1d.jpg	Test upload prop-006	0	f	2025-09-22 15:45:10.318205	/uploads/properties/prop-006/prop_prop-006_prop_prop-008_9_ap_oborichte_1758550168_1b6229_1758555910_4b7b1d_thumb.jpg	309366	image/jpeg
255e9ef8-99dd-471b-8315-c7b5c30f896c	prop-002	/uploads/properties/prop-002/prop_prop-002_3_kachta_dragalevci_1758554987_226c57.jpg	/uploads/properties/prop-002/prop_prop-002_3_kachta_dragalevci_1758554987_226c57.jpg	Property image	0	f	2025-09-22 15:29:47.309978	/uploads/properties/prop-002/prop_prop-002_3_kachta_dragalevci_1758554987_226c57_thumb.jpg	162960	image/jpeg
0290fcba-4e3d-4ab9-a93b-96efd505e851	prop-002	/uploads/properties/prop-002/prop_prop-002_5_kachta_dragalevci_1758554992_39fd1c.jpg	/uploads/properties/prop-002/prop_prop-002_5_kachta_dragalevci_1758554992_39fd1c.jpg	Property image	0	t	2025-09-22 15:29:53.117166	/uploads/properties/prop-002/prop_prop-002_5_kachta_dragalevci_1758554992_39fd1c_thumb.jpg	118382	image/jpeg
3ce3e77b-d943-4a76-927f-c7503408ffcb	prop-010	/uploads/properties/prop-010/prop_prop-010_8_ap_oborichte_1758556364_8fe5d8.jpg	/uploads/properties/prop-010/prop_prop-010_8_ap_oborichte_1758556364_8fe5d8.jpg	Property image	0	f	2025-09-22 15:52:44.889899	/uploads/properties/prop-010/prop_prop-010_8_ap_oborichte_1758556364_8fe5d8_thumb.jpg	309665	image/jpeg
a9ad66bc-01f0-42ec-8685-5c41b5f5a269	prop-007	/uploads/properties/prop-007/prop_prop-007_prop_prop-008_9_ap_oborichte_1758550168_1b6229_1758555912_a89cc8.jpg	/uploads/properties/prop-007/prop_prop-007_prop_prop-008_9_ap_oborichte_1758550168_1b6229_1758555912_a89cc8.jpg	Test upload prop-007	0	f	2025-09-22 15:45:13.15881	/uploads/properties/prop-007/prop_prop-007_prop_prop-008_9_ap_oborichte_1758550168_1b6229_1758555912_a89cc8_thumb.jpg	309366	image/jpeg
cfe7e97a-31e7-4b16-8f85-e5760ddf0ab2	prop-007	/uploads/properties/prop-007/prop_prop-007_8_ap_oborichte_1758556391_ce5ce9.jpg	/uploads/properties/prop-007/prop_prop-007_8_ap_oborichte_1758556391_ce5ce9.jpg	Property image	0	t	2025-09-22 15:53:12.10409	/uploads/properties/prop-007/prop_prop-007_8_ap_oborichte_1758556391_ce5ce9_thumb.jpg	309665	image/jpeg
fbc82b3c-9bcf-48e4-8785-ebce28ac454d	prop-008	/uploads/properties/prop-008/prop_prop-008_ap_oborichte_4_1758556443_1989d4.jpg	/uploads/properties/prop-008/prop_prop-008_ap_oborichte_4_1758556443_1989d4.jpg	Property image	0	f	2025-09-22 15:54:04.116271	/uploads/properties/prop-008/prop_prop-008_ap_oborichte_4_1758556443_1989d4_thumb.jpg	290621	image/jpeg
e600f936-3304-4d3b-a179-b8576b8cf862	prop-008	/uploads/properties/prop-008/prop_prop-008_prop_prop-008_9_ap_oborichte_1758550168_1b6229_1758555915_e08465.jpg	/uploads/properties/prop-008/prop_prop-008_prop_prop-008_9_ap_oborichte_1758550168_1b6229_1758555915_e08465.jpg	Test upload prop-008	0	f	2025-09-22 15:45:16.169123	/uploads/properties/prop-008/prop_prop-008_prop_prop-008_9_ap_oborichte_1758550168_1b6229_1758555915_e08465_thumb.jpg	309366	image/jpeg
1c10b4b5-7821-4471-9985-35e4539afcb0	prop-009	/uploads/properties/prop-009/prop_prop-009_ap_oborichte_5_1758556473_091f6d.jpg	/uploads/properties/prop-009/prop_prop-009_ap_oborichte_5_1758556473_091f6d.jpg	Property image	0	f	2025-09-22 15:54:33.540612	/uploads/properties/prop-009/prop_prop-009_ap_oborichte_5_1758556473_091f6d_thumb.jpg	427577	image/jpeg
f32c63ce-c72d-4a91-8292-9815a68ef562	prop-009	/uploads/properties/prop-009/prop_prop-009_2_kachta_dragalevci_1758557417_56c8b8.jpg	/uploads/properties/prop-009/prop_prop-009_2_kachta_dragalevci_1758557417_56c8b8.jpg	Property image	0	f	2025-09-22 16:10:17.75952	/uploads/properties/prop-009/prop_prop-009_2_kachta_dragalevci_1758557417_56c8b8_thumb.jpg	129224	image/jpeg
img-001	prop-001	/images/prop-001/1_kachta_simeonovo.jpg	/images/prop-001/1_kachta_simeonovo.jpg	Луксозен апартамент в Симеоново - главна снимка	0	f	2025-09-22 11:17:23.062397	\N	0	\N
img-002	prop-001	/images/prop-001/2_kachta_simeonovo.jpg	/images/prop-001/2_kachta_simeonovo.jpg	Луксозен апартамент в Симеоново - всекидневна	1	f	2025-09-22 11:17:23.062397	\N	0	\N
img-003	prop-001	/images/prop-001/3_kachta_simeonovo.jpg	/images/prop-001/3_kachta_simeonovo.jpg	Луксозен апартамент в Симеоново - спалня	2	f	2025-09-22 11:17:23.062397	\N	0	\N
24d9cf60-d6d8-4233-a18a-029912e956a9	prop-008	/uploads/properties/prop-008/prop_prop-008_9_ap_oborichte_1758556419_dc4fc4.jpg	/uploads/properties/prop-008/prop_prop-008_9_ap_oborichte_1758556419_dc4fc4.jpg	Property image	0	f	2025-09-22 15:53:39.328404	/uploads/properties/prop-008/prop_prop-008_9_ap_oborichte_1758556419_dc4fc4_thumb.jpg	309193	image/jpeg
acad0b90-7f0a-4711-9420-5e70953606f4	prop-008	/uploads/properties/prop-008/prop_prop-008_ap_oborichte_5_1758558531_08523b.jpg	/uploads/properties/prop-008/prop_prop-008_ap_oborichte_5_1758558531_08523b.jpg	Property image	0	t	2025-09-22 16:28:51.741634	/uploads/properties/prop-008/prop_prop-008_ap_oborichte_5_1758558531_08523b_thumb.jpg	427577	image/jpeg
490fe097-8b8b-4bfa-84f8-334c770c3c8f	prop-001	/uploads/properties/prop-001/prop_prop-001_1_kachta_dragalevci_1758561596_70197d.jpg	/uploads/properties/prop-001/prop_prop-001_1_kachta_dragalevci_1758561596_70197d.jpg	Property image	0	f	2025-09-22 17:19:56.344789	/uploads/properties/prop-001/prop_prop-001_1_kachta_dragalevci_1758561596_70197d_thumb.jpg	137932	image/jpeg
07d9ea3b-d324-42c5-8fc7-370156307a37	prop-001	/uploads/properties/prop-001/prop_prop-001_2_kachta_dragalevci_1758561600_d99a8a.jpg	/uploads/properties/prop-001/prop_prop-001_2_kachta_dragalevci_1758561600_d99a8a.jpg	Property image	0	t	2025-09-22 17:20:00.531059	/uploads/properties/prop-001/prop_prop-001_2_kachta_dragalevci_1758561600_d99a8a_thumb.jpg	129224	image/jpeg
\.


--
-- Data for Name: sections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sections (id, title, content, type, active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, title, description, icon, active, sort_order, created_at, updated_at) FROM stdin;
srv-001	Продажба на имоти	Професионални услуги за продажба на всички видове имоти	home	t	0	2025-09-22 11:17:12.254228	2025-09-22 11:17:12.254228
srv-002	Инвестиционни консултации	Експертни съвети за инвестиции в недвижими имоти	trending-up	t	0	2025-09-22 11:17:12.254228	2025-09-22 11:17:12.254228
srv-003	Правна защита	Пълна правна подкрепа при всички сделки с имоти	shield	t	0	2025-09-22 11:17:12.254228	2025-09-22 11:17:12.254228
srv-004	Управление на имоти	Професионално управление и поддръжка на имоти	settings	t	0	2025-09-22 11:17:12.254228	2025-09-22 11:17:12.254228
srv-005	Оценка на имоти	Точна пазарна оценка на всички видове имоти	calculator	t	0	2025-09-22 11:17:12.254228	2025-09-22 11:17:12.254228
srv-006	24/7 Поддръжка	Денонощна поддръжка за всички клиенти	phone	t	0	2025-09-22 11:17:12.254228	2025-09-22 11:17:12.254228
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, name, role, active, created_at, updated_at) FROM stdin;
user-001	georgiev@consultingg.com	$2y$10$rQikecKgwIS3DG7cEf7xEexEUA7veePAnmBMshRGwb0/YIcKYALS2	Георги Георгиев	admin	t	2025-09-22 11:17:12.254228	2025-09-22 11:17:12.254228
\.


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key UNIQUE (slug);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_documents property_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_documents
    ADD CONSTRAINT property_documents_pkey PRIMARY KEY (id);


--
-- Name: property_images property_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_images
    ADD CONSTRAINT property_images_pkey PRIMARY KEY (id);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: properties unique_property_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT unique_property_code UNIQUE (property_code);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_properties_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_properties_active ON public.properties USING btree (active);


--
-- Name: idx_properties_city_region; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_properties_city_region ON public.properties USING btree (city_region);


--
-- Name: idx_properties_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_properties_created_at ON public.properties USING btree (created_at);


--
-- Name: idx_properties_featured; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_properties_featured ON public.properties USING btree (featured);


--
-- Name: idx_properties_price; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_properties_price ON public.properties USING btree (price);


--
-- Name: idx_properties_property_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_properties_property_type ON public.properties USING btree (property_type);


--
-- Name: idx_properties_transaction_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_properties_transaction_type ON public.properties USING btree (transaction_type);


--
-- Name: idx_property_documents_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_documents_property_id ON public.property_documents USING btree (property_id);


--
-- Name: idx_property_images_is_main; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_images_is_main ON public.property_images USING btree (is_main);


--
-- Name: idx_property_images_property_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_images_property_id ON public.property_images USING btree (property_id);


--
-- Name: idx_property_images_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_property_images_sort_order ON public.property_images USING btree (sort_order);


--
-- Name: property_documents property_documents_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_documents
    ADD CONSTRAINT property_documents_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- Name: property_images property_images_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_images
    ADD CONSTRAINT property_images_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

