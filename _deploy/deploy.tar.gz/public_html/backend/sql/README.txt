Базата има property_images (id VARCHAR, image_url, image_path, is_main) и работи с is_main. 

Няма нужда от properties.main_image_id. 

Ако таблицата някъде липсва — импортнете от последния dump.